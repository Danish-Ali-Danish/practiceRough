
import React from 'react';
import LaravelIcon from './icons/LaravelIcon';

const skills = [
  { name: 'HTML', iconClass: 'bx bxl-html5 text-orange-500', animation: 'animate-bounce' },
  { name: 'CSS', iconClass: 'bx bxl-css3 text-blue-500', animation: 'animate-pulse' },
  { name: 'JavaScript', iconClass: 'bx bxl-javascript text-yellow-400', animation: 'animate-spin' },
  { name: 'Tailwind', iconClass: 'bx bxl-tailwind-css text-cyan-400', animation: 'animate-bounce' },
  { name: 'Bootstrap', iconClass: 'bx bxl-bootstrap text-purple-600', animation: 'animate-pulse' },
  { name: 'PHP', iconClass: 'bx bxl-php text-indigo-400', animation: 'animate-bounce' },
  { name: 'MySQL', iconClass: 'bx bxs-data text-green-400', animation: 'animate-pulse' },
  { name: 'Laravel', iconClass: 'text-red-500', animation: 'animate-bounce', isCustom: true },
];

const SkillCard: React.FC<{ skill: typeof skills[0], delay: number }> = ({ skill, delay }) => {
  return (
    <div 
      className="bg-gray-800 p-6 rounded-xl shadow-lg text-center transform transition hover:scale-110" 
      data-aos="zoom-in" 
      data-aos-delay={delay}
    >
      {skill.isCustom ? (
        <div className={`mx-auto w-12 h-12 ${skill.iconClass} ${skill.animation}`}>
          <LaravelIcon />
        </div>
      ) : (
        <i className={`${skill.iconClass} text-5xl ${skill.animation}`}></i>
      )}
      <p className="mt-2 font-semibold">{skill.name}</p>
    </div>
  );
};

const Skills: React.FC = () => {
  return (
    <section id="skills" className="py-20 bg-gray-900">
      <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Skills</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-8 max-w-6xl mx-auto px-6">
        {skills.map((skill, index) => (
          <SkillCard key={skill.name} skill={skill} delay={index * 50} />
        ))}
      </div>
    </section>
  );
};

export default Skills;
