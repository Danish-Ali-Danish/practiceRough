
import React from 'react';

interface NavbarProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ theme, toggleTheme }) => {
  return (
    <nav className="fixed w-full z-50 bg-gray-900/80 backdrop-blur-lg shadow-lg transition-colors duration-500">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        <h1 className="text-2xl font-extrabold gradient-text">Danish.dev</h1>
        <ul className="hidden md:flex space-x-8 font-medium">
          <li><a href="#hero" className="hover:text-cyan-400 transition">Home</a></li>
          <li><a href="#skills" className="hover:text-cyan-400 transition">Skills</a></li>
          <li><a href="#projects" className="hover:text-cyan-400 transition">Projects</a></li>
          <li><a href="#contact" className="hover:text-cyan-400 transition">Contact</a></li>
        </ul>
        <button onClick={toggleTheme} className="text-2xl p-2 rounded-full hover:bg-gray-700/50 transition-colors" aria-label="Toggle theme">
          {theme === 'dark' ? <i className='bx bxs-moon'></i> : <i className='bx bxs-sun'></i>}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
