
import React, { useState, useEffect } from 'react';

const ScrollProgressBar: React.FC = () => {
  const [width, setWidth] = useState(0);

  const handleScroll = () => {
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (scrollTop / scrollHeight) * 100;
    setWidth(scrolled);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div
      style={{ width: `${width}%` }}
      className="fixed top-0 left-0 h-[6px] bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 z-[1000] rounded-r-full transition-all duration-75 ease-out"
    ></div>
  );
};

export default ScrollProgressBar;
