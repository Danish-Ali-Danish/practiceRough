
import React from 'react';

const services = [
  {
    title: 'Web Development',
    description: 'Custom, responsive websites with clean code.',
    icon: 'bx bx-code-block',
  },
  {
    title: 'API Integration',
    description: 'RESTful APIs, payment gateways, 3rd‑party services.',
    icon: 'bx bx-cloud',
  },
  {
    title: 'Database Design',
    description: 'MySQL schema, optimization, backups, migrations.',
    icon: 'bx bx-data',
  },
];

const ServiceCard: React.FC<{ service: typeof services[0], delay: number }> = ({ service, delay }) => (
  <div 
    className="bg-gray-800 rounded-2xl p-6 border border-white/5 hover:border-cyan-500/40 transition shadow-lg" 
    data-aos="flip-left"
    data-aos-delay={delay}
  >
    <i className={`${service.icon} text-4xl text-cyan-400`}></i>
    <h4 className="mt-4 text-xl font-semibold">{service.title}</h4>
    <p className="mt-2 text-gray-400">{service.description}</p>
  </div>
);

const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 bg-gray-900">
      <h3 className="text-4xl font-bold text-center mb-12 gradient-text">Services</h3>
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 px-6">
        {services.map((service, index) => (
          <ServiceCard key={service.title} service={service} delay={index * 100} />
        ))}
      </div>
    </section>
  );
};

export default Services;
