@extends('layouts.frontend')

@section('content')
<section class="pt-24 pb-12 bg-slate-950">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-2xl sm:text-3xl font-bold mb-6">Category: {{ $category->name }}</h1>

    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
      @forelse($posts as $post)
      <article class="group rounded-2xl overflow-hidden bg-white/5 ring-1 ring-white/10 shadow-soft">
        <img class="h-48 w-full object-cover group-hover:scale-105 transition" src="{{ $post->image ?? 'https://source.unsplash.com/800x500/?blog' }}" alt="" />
        <div class="p-5">
          <div class="flex items-center gap-2 text-[10px] uppercase tracking-wide">
            <span class="px-2 py-1 rounded-full bg-indigo-500/90">{{ $post->type ?? 'Post' }}</span>
            <span class="text-slate-400">{{ $category->name }}</span>
          </div>
          <h3 class="mt-2 font-semibold text-lg">
            <a href="{{ route('blog.post', $post->slug) }}">{{ $post->title }}</a>
          </h3>
          <p class="mt-1 text-sm text-slate-300 line-clamp-2">{{ $post->excerpt }}</p>
        </div>
      </article>
      @empty
        <p class="text-slate-400">No posts in this category yet.</p>
      @endforelse
    </div>

    <div class="mt-10">
      {{ $posts->links() }}
    </div>
  </div>
</section>
@endsection
