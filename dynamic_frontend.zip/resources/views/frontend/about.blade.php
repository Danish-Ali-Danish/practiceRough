@extends('layouts.frontend')

@section('content')
<section class="pt-28 pb-20 noise bg-hero-gradient">
  <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-4xl font-extrabold mb-4">About</h1>
    <p class="text-slate-300 leading-relaxed">
      This page uses the same design system as the home page. Replace this text with your actual About content.
    </p>
  </div>
</section>
@endsection
