# Dynamic Frontend (Laravel)

Files generated: controller, models, seeders, and Blade views.

## How to apply
1) Copy `app/Http/Controllers/FrontendController.php` into your project.
2) Copy/merge `app/Models/Post.php` and `app/Models/Category.php` (ensure fillable fields match your migration).
3) Copy Blade files into `resources/views/...` (keep the same structure).
4) Fix routes if needed (already matching your previous message).
5) Run: `php artisan migrate:fresh --seed` to seed sample data.
6) Visit `/` for Home, `/blog` for listing, `/blog/{slug}` for detail, `/category/{slug}` for category.

Generated at: 2025-08-27T00:24:37.674261Z
