<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Post;
use App\Models\Category;
use Illuminate\Support\Str;

class PostSeeder extends Seeder
{
    public function run(): void
    {
        $cat1 = Category::firstOrCreate(['slug' => 'laravel'], ['name' => 'Laravel']);
        $cat2 = Category::firstOrCreate(['slug' => 'ai'], ['name' => 'AI']);
        $cat3 = Category::firstOrCreate(['slug' => 'design'], ['name' => 'Design']);

        $posts = [
            [
                'title' => 'Mastering Laravel Eloquent',
                'slug' => 'mastering-laravel-eloquent',
                'image' => null,
                'type' => 'Guide',
                'excerpt' => 'Tips and tricks for optimizing Laravel Eloquent queries.',
                'content' => 'This is the full article content about mastering Laravel Eloquent...',
                'category_id' => $cat1->id,
            ],
            [
                'title' => 'The Future of AI in Web Dev',
                'slug' => 'future-of-ai-in-web-dev',
                'image' => null,
                'type' => 'AI',
                'excerpt' => 'From code generation to smart testing, see how AI is changing our workflow.',
                'content' => 'AI is reshaping the developer workflow...',
                'category_id' => $cat2->id,
            ],
            [
                'title' => 'Minimal UI Patterns',
                'slug' => 'minimal-ui-patterns',
                'image' => null,
                'type' => 'Design',
                'excerpt' => 'Clean, modern patterns you can reuse.',
                'content' => 'Design patterns for clean UI...',
                'category_id' => $cat3->id,
            ],
        ];

        foreach ($posts as $p) {
            Post::updateOrCreate(['slug' => $p['slug']], $p);
        }
    }
}
