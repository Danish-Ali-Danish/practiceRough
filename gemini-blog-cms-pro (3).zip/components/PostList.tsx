
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Post } from '../types';
import Card from './common/Card';
import Button from './common/Button';
import Modal from './common/Modal';

interface PostListProps {
  posts: Post[];
  onDelete: (postId: string) => void;
}

const PostList: React.FC<PostListProps> = ({ posts, onDelete }) => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [postToDelete, setPostToDelete] = useState<Post | null>(null);

  const openDeleteModal = (post: Post) => {
    setPostToDelete(post);
    setIsModalOpen(true);
  };

  const closeDeleteModal = () => {
    setPostToDelete(null);
    setIsModalOpen(false);
  };

  const confirmDelete = () => {
    if (postToDelete) {
      onDelete(postToDelete.id);
      closeDeleteModal();
    }
  };

  return (
    <>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-superlight">Posts</h2>
        <Button onClick={() => navigate('/posts/new')} icon="fa-plus">
          New Post
        </Button>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="p-4 text-sm font-semibold">Title</th>
                <th className="p-4 text-sm font-semibold">Status</th>
                <th className="p-4 text-sm font-semibold">Created</th>
                <th className="p-4 text-sm font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {posts.map(post => (
                <tr key={post.id} className="border-b border-slate-800 hover:bg-slate-800/50">
                  <td className="p-4 font-medium text-superlight">{post.title}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${post.status === 'Published' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                      {post.status}
                    </span>
                  </td>
                  <td className="p-4">{new Date(post.createdAt).toLocaleDateString()}</td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => navigate(`/posts/edit/${post.id}`)} aria-label="Edit Post">
                        <i className="fa-solid fa-pencil"></i>
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => openDeleteModal(post)} className="text-danger hover:bg-danger/20" aria-label="Delete Post">
                        <i className="fa-solid fa-trash"></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={closeDeleteModal}
        title="Confirm Deletion"
      >
        <p className="mb-6">Are you sure you want to delete the post "{postToDelete?.title}"? This action cannot be undone.</p>
        <div className="flex justify-end space-x-4">
          <Button variant="secondary" onClick={closeDeleteModal}>Cancel</Button>
          <Button variant="danger" onClick={confirmDelete}>Delete</Button>
        </div>
      </Modal>
    </>
  );
};

export default PostList;
