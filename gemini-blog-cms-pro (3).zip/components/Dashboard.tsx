
import React from 'react';
import { Link } from 'react-router-dom';
import type { Post } from '../types';
import Card from './common/Card';

interface DashboardProps {
  posts: Post[];
}

const StatCard: React.FC<{ icon: string; label: string; value: string; color: string }> = ({ icon, label, value, color }) => (
    <Card className="flex items-center p-4">
        <div className={`flex items-center justify-center w-12 h-12 rounded-full mr-4 ${color}`}>
            <i className={`fa-solid ${icon} text-xl text-white`}></i>
        </div>
        <div>
            <p className="text-sm text-light">{label}</p>
            <p className="text-2xl font-bold text-superlight">{value}</p>
        </div>
    </Card>
);

const Dashboard: React.FC<DashboardProps> = ({ posts }) => {
  const totalViews = posts.reduce((sum, post) => sum + post.views, 0).toLocaleString();
  const totalLikes = posts.reduce((sum, post) => sum + post.likes, 0).toLocaleString();
  const totalComments = posts.reduce((sum, post) => sum + post.comments, 0).toLocaleString();
  const totalPosts = posts.length.toString();
  const recentPosts = posts.slice(0, 5);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-superlight mb-4">Dashboard</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon="fa-eye" label="Total Views" value={totalViews} color="bg-blue-500" />
        <StatCard icon="fa-heart" label="Total Likes" value={totalLikes} color="bg-pink-500" />
        <StatCard icon="fa-comments" label="Total Comments" value={totalComments} color="bg-green-500" />
        <StatCard icon="fa-file-alt" label="Total Posts" value={totalPosts} color="bg-yellow-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2">
            <h3 className="text-xl font-semibold text-superlight mb-4">Recent Posts</h3>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead>
                        <tr className="border-b border-slate-700">
                            <th className="py-2 text-sm font-semibold">Title</th>
                            <th className="py-2 text-sm font-semibold">Status</th>
                            <th className="py-2 text-sm font-semibold text-right">Views</th>
                        </tr>
                    </thead>
                    <tbody>
                        {recentPosts.map(post => (
                            <tr key={post.id} className="border-b border-slate-800 hover:bg-slate-800/50">
                                <td className="py-3 pr-4">
                                    <Link to={`/posts/edit/${post.id}`} className="hover:text-accent font-medium text-superlight">{post.title}</Link>
                                </td>
                                <td className="py-3 pr-4">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${post.status === 'Published' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                                        {post.status}
                                    </span>
                                </td>
                                <td className="py-3 text-right">{post.views.toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
        
        <Card>
            <h3 className="text-xl font-semibold text-superlight mb-4">Quick Actions</h3>
            <div className="space-y-3">
                <Link to="/posts/new" className="w-full flex items-center justify-center px-4 py-3 text-sm font-medium text-white bg-accent rounded-md shadow-sm hover:bg-sky-400 transition-colors duration-200">
                    <i className="fa-solid fa-plus mr-2"></i> Write New Post
                </Link>
                <Link to="/posts" className="w-full flex items-center justify-center px-4 py-3 text-sm font-medium text-superlight bg-slate-700 rounded-md shadow-sm hover:bg-slate-600 transition-colors duration-200">
                    <i className="fa-solid fa-file-alt mr-2"></i> Manage Posts
                </Link>
                <Link to="/analytics" className="w-full flex items-center justify-center px-4 py-3 text-sm font-medium text-superlight bg-slate-700 rounded-md shadow-sm hover:bg-slate-600 transition-colors duration-200">
                     <i className="fa-solid fa-chart-line mr-2"></i> View Analytics
                </Link>
            </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
