
// Simple CRUD for Users example
let users = [
  {id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin', status: 'Active'},
  {id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Manager', status: 'Inactive'}
];

function renderUsers() {
    const tbody = document.getElementById('user-tbody');
    tbody.innerHTML = '';
    users.forEach(user => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td class="px-4 py-2">${user.id}</td>
                        <td class="px-4 py-2">${user.name}</td>
                        <td class="px-4 py-2">${user.email}</td>
                        <td class="px-4 py-2">${user.role}</td>
                        <td class="px-4 py-2">${user.status}</td>
                        <td class="px-4 py-2">
                            <button onclick="editUser(${user.id})" class="text-blue-500 mr-2">Edit</button>
                            <button onclick="deleteUser(${user.id})" class="text-red-500">Delete</button>
                        </td>`;
        tbody.appendChild(tr);
    });
}

function addUser() {
    const name = prompt('Enter Name:');
    const email = prompt('Enter Email:');
    const role = prompt('Enter Role:');
    const status = prompt('Enter Status:');
    const id = users.length ? users[users.length-1].id + 1 : 1;
    users.push({id, name, email, role, status});
    renderUsers();
}

function editUser(id) {
    const user = users.find(u => u.id === id);
    if(!user) return;
    user.name = prompt('Edit Name:', user.name);
    user.email = prompt('Edit Email:', user.email);
    user.role = prompt('Edit Role:', user.role);
    user.status = prompt('Edit Status:', user.status);
    renderUsers();
}

function deleteUser(id) {
    if(confirm('Delete this user?')) {
        users = users.filter(u => u.id !== id);
        renderUsers();
    }
}

window.onload = () => {
    renderUsers();
}
