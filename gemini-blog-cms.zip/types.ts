
export interface Post {
    id: string;
    title: string;
    content: string;
    imageUrl: string | null;
    createdAt: string;
}

export enum AITool {
    Ideas = 'Ideas',
    Outline = 'Outline',
    Article = 'Article',
    Image = 'Image',
}
