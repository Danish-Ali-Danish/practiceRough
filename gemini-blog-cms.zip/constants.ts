
import { type Post } from './types';
import { v4 as uuidv4 } from 'uuid';

export const DUMMY_POSTS: Post[] = [
    {
        id: uuidv4(),
        title: 'Getting Started with React and Tailwind CSS',
        content: `
# Welcome to Your New Blog!

This is your first post, created to get you started. You can edit or delete it from the sidebar.

## Key Features

*   **AI-Powered Content:** Use the AI panel to generate ideas, outlines, or entire articles.
*   **AI Image Generation:** Create stunning header images with a simple prompt.
*   **Live Preview:** See your Markdown rendered in real-time.
*   **Sleek UI:** A modern, dark-themed interface built for focus.

Happy writing!
        `,
        imageUrl: 'https://picsum.photos/seed/react/1200/600',
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    },
    {
        id: uuidv4(),
        title: 'The Power of AI in Modern Web Development',
        content: `
# Exploring AI in Web Dev

Artificial intelligence is no longer a futuristic concept; it's a tool that's reshaping web development today.

*   **Code Completion:** Tools like GitHub Copilot accelerate development.
*   **Automated Testing:** AI can generate test cases and identify bugs.
*   **Content Creation:** As you can see with this app, AI can help create engaging content effortlessly.

The possibilities are endless.
        `,
        imageUrl: 'https://picsum.photos/seed/ai/1200/600',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    },
];
