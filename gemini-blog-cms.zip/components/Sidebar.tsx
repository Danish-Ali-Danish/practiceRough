
import React from 'react';
import { type Post } from '../types';
import { PlusCircle, Trash2 } from 'lucide-react';

interface SidebarProps {
    posts: Post[];
    selectedPostId: string | null;
    onSelectPost: (id: string) => void;
    onCreatePost: () => void;
    onDeletePost: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ posts, selectedPostId, onSelectPost, onCreatePost, onDeletePost }) => {
    
    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    return (
        <aside className="w-80 bg-secondary border-r border-tertiary flex flex-col flex-shrink-0">
            <div className="p-4 border-b border-tertiary">
                <button
                    onClick={onCreatePost}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-accent-blue text-white font-semibold rounded-lg shadow-md hover:bg-blue-500 transition-all duration-300"
                >
                    <PlusCircle size={18} />
                    New Post
                </button>
            </div>
            <div className="flex-grow overflow-y-auto">
                {posts.length > 0 ? (
                    <ul>
                        {posts.map(post => (
                            <li key={post.id}>
                                <div
                                    onClick={() => onSelectPost(post.id)}
                                    className={`flex justify-between items-start p-4 cursor-pointer border-b border-tertiary transition-colors duration-200 ${selectedPostId === post.id ? 'bg-tertiary' : 'hover:bg-tertiary/50'}`}
                                >
                                    <div className="flex-grow pr-2 overflow-hidden">
                                        <h3 className={`font-semibold truncate ${selectedPostId === post.id ? 'text-accent-blue' : 'text-text-primary'}`}>{post.title}</h3>
                                        <p className="text-xs text-text-secondary mt-1">{formatDate(post.createdAt)}</p>
                                    </div>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            if (window.confirm('Are you sure you want to delete this post?')) {
                                                onDeletePost(post.id);
                                            }
                                        }}
                                        className="p-1 text-text-secondary hover:text-red-500 transition-colors duration-200 flex-shrink-0"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="p-4 text-center text-text-secondary">
                        <p>No posts yet. Create one to get started!</p>
                    </div>
                )}
            </div>
        </aside>
    );
};

export default Sidebar;
