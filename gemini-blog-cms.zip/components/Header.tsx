
import React from 'react';
import { BotMessageSquare } from 'lucide-react';

const Header: React.FC = () => {
    return (
        <header className="flex items-center justify-between p-4 bg-secondary border-b border-tertiary shadow-md flex-shrink-0">
            <div className="flex items-center gap-3">
                <BotMessageSquare className="text-accent-blue" size={32} />
                <h1 className="text-xl font-bold text-text-primary">
                    Gemini Blog <span className="text-accent-blue">CMS</span>
                </h1>
            </div>
            {/* Future elements like user avatar or settings can go here */}
        </header>
    );
};

export default Header;
