
import React, { useState, useEffect } from 'react';
import { type Post } from '../types';

interface EditorProps {
    post: Post;
    onUpdatePost: (updatedPost: Partial<Post>) => void;
}

const Editor: React.FC<EditorProps> = ({ post, onUpdatePost }) => {
    const [title, setTitle] = useState(post.title);
    const [content, setContent] = useState(post.content);

    useEffect(() => {
        setTitle(post.title);
        setContent(post.content);
    }, [post]);

    const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setTitle(e.target.value);
        onUpdatePost({ title: e.target.value });
    };

    const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setContent(e.target.value);
        onUpdatePost({ content: e.target.value });
    };

    return (
        <div className="flex-grow flex flex-col animate-fade-in">
            <input
                type="text"
                value={title}
                onChange={handleTitleChange}
                placeholder="Blog Post Title"
                className="w-full bg-tertiary text-text-primary text-2xl font-bold p-4 rounded-t-lg border-b-2 border-accent-blue focus:outline-none focus:ring-0"
            />
            <textarea
                value={content}
                onChange={handleContentChange}
                placeholder="Write your blog post content here... (Markdown is supported)"
                className="w-full flex-grow bg-secondary text-text-secondary p-4 rounded-b-lg focus:outline-none focus:ring-0 resize-none font-mono"
            />
        </div>
    );
};

export default Editor;
