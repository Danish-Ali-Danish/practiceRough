
import React from 'react';
import { marked } from 'marked';
import { type Post } from '../types';
import { ImageOff } from 'lucide-react';

interface PreviewProps {
    post: Post;
}

const Preview: React.FC<PreviewProps> = ({ post }) => {
    const { title, content, imageUrl } = post;
    const getHTML = (markdown: string) => {
        return { __html: marked.parse(markdown) };
    };

    return (
        <div className="flex flex-col animate-fade-in h-full">
            <h2 className="text-2xl font-bold mb-4 text-text-primary flex-shrink-0">Preview</h2>
            <div className="bg-secondary rounded-lg shadow-lg overflow-y-auto flex-grow">
                 {imageUrl ? (
                    <img src={imageUrl} alt={title} className="w-full h-64 object-cover" />
                ) : (
                    <div className="w-full h-64 bg-tertiary flex items-center justify-center text-text-secondary">
                        <ImageOff size={48} />
                    </div>
                )}
                <div className="p-8">
                    <h1 className="text-4xl font-extrabold text-text-primary mb-6 border-b-2 border-accent-blue pb-4">{title}</h1>
                    <div
                        className="prose prose-invert prose-lg max-w-none prose-h1:text-accent-blue prose-h2:text-accent-purple prose-a:text-accent-blue prose-strong:text-text-primary"
                        dangerouslySetInnerHTML={getHTML(content)}
                    />
                </div>
            </div>
        </div>
    );
};

export default Preview;
