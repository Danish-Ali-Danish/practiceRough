
import React, { useState } from 'react';
import { toast } from 'react-hot-toast';
import { type Post, AITool } from '../types';
import { generateBlogPostIdeas, generateBlogPostOutline, generateFullArticle, generateImage } from '../services/geminiService';
import Button from './common/Button';
import Spinner from './common/Spinner';
import { Lightbulb, ListCollapse, FileText, Image } from 'lucide-react';

interface AIPanelProps {
    currentTitle: string;
    onUpdatePost: (updatedPost: Partial<Post>) => void;
}

const AIPanel: React.FC<AIPanelProps> = ({ currentTitle, onUpdatePost }) => {
    const [activeTool, setActiveTool] = useState<AITool>(AITool.Ideas);
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [generatedIdeas, setGeneratedIdeas] = useState<string[]>([]);

    const handleGenerate = async () => {
        if (!prompt && activeTool !== AITool.Outline && activeTool !== AITool.Article) {
            toast.error('Please enter a topic or prompt.');
            return;
        }

        setIsLoading(true);
        try {
            switch (activeTool) {
                case AITool.Ideas:
                    const ideas = await generateBlogPostIdeas(prompt);
                    setGeneratedIdeas(ideas);
                    toast.success('Ideas generated!');
                    break;
                case AITool.Outline:
                    const outline = await generateBlogPostOutline(currentTitle);
                    onUpdatePost({ content: outline });
                    toast.success('Outline generated and inserted!');
                    break;
                case AITool.Article:
                    const article = await generateFullArticle(currentTitle);
                    onUpdatePost({ content: article });
                    toast.success('Article generated and inserted!');
                    break;
                case AITool.Image:
                    const finalPrompt = prompt || currentTitle;
                    const imageUrl = await generateImage(finalPrompt);
                    onUpdatePost({ imageUrl });
                    toast.success('Image generated and set!');
                    break;
            }
        } catch (error) {
            toast.error((error as Error).message);
        } finally {
            setIsLoading(false);
        }
    };

    const renderToolContent = () => {
        switch (activeTool) {
            case AITool.Ideas:
                return (
                    <>
                        <input
                            type="text"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Enter a topic (e.g., 'React Hooks')"
                            className="w-full bg-tertiary text-text-primary p-2 rounded focus:outline-none focus:ring-2 focus:ring-accent-blue"
                        />
                        {generatedIdeas.length > 0 && (
                            <div className="mt-4 space-y-2">
                                {generatedIdeas.map((idea, index) => (
                                    <div key={index} className="bg-secondary p-3 rounded flex justify-between items-center">
                                        <p className="text-sm text-text-secondary">{idea}</p>
                                        <button onClick={() => { onUpdatePost({ title: idea }); toast.success('Title updated!') }} className="text-xs bg-accent-blue text-white px-2 py-1 rounded hover:bg-blue-500">Use</button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                );
            case AITool.Outline:
                return <p className="text-sm text-text-secondary">Generate an outline for the current post title: <strong className="text-text-primary">"{currentTitle}"</strong>.</p>;
            case AITool.Article:
                return <p className="text-sm text-text-secondary">Generate a full article for the current post title: <strong className="text-text-primary">"{currentTitle}"</strong>.</p>;
            case AITool.Image:
                return (
                    <input
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Image prompt (or use post title)"
                        className="w-full bg-tertiary text-text-primary p-2 rounded focus:outline-none focus:ring-2 focus:ring-accent-blue"
                    />
                );
        }
    };
    
    const toolIcons = {
        [AITool.Ideas]: <Lightbulb size={16} />,
        [AITool.Outline]: <ListCollapse size={16} />,
        [AITool.Article]: <FileText size={16} />,
        [AITool.Image]: <Image size={16} />,
    };

    return (
        <div className="mt-6 p-4 bg-tertiary rounded-lg border border-gray-700 animate-slide-in">
            <h3 className="text-lg font-bold mb-4 text-accent-purple">Gemini AI Assistant</h3>
            <div className="flex items-center gap-2 mb-4 border-b border-gray-700 pb-4">
                {Object.values(AITool).map(tool => (
                     <button
                        key={tool}
                        onClick={() => setActiveTool(tool)}
                        className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${activeTool === tool ? 'bg-accent-blue text-white' : 'bg-secondary text-text-secondary hover:bg-secondary/70'}`}
                    >
                        {toolIcons[tool]}
                        {tool}
                    </button>
                ))}
            </div>
            <div className="space-y-4">
                {renderToolContent()}
                <Button onClick={handleGenerate} disabled={isLoading} className="w-full">
                    {isLoading ? <Spinner /> : `Generate ${activeTool}`}
                </Button>
            </div>
        </div>
    );
};

export default AIPanel;
