
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateBlogPostIdeas = async (topic: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate 5 engaging blog post titles about "${topic}".`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        ideas: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING
                            }
                        }
                    }
                }
            }
        });
        const jsonResponse = JSON.parse(response.text);
        return jsonResponse.ideas || [];
    } catch (error) {
        console.error("Error generating blog post ideas:", error);
        throw new Error("Failed to generate blog post ideas.");
    }
};

export const generateBlogPostOutline = async (title: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Create a detailed blog post outline in Markdown format for the title: "${title}". Include headings and bullet points for key topics.`,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating blog post outline:", error);
        throw new Error("Failed to generate blog post outline.");
    }
};

export const generateFullArticle = async (title: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Write a complete blog post in Markdown format for the title: "${title}". The article should be well-structured, informative, and engaging. Use headings, lists, and bold text where appropriate.`,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating full article:", error);
        throw new Error("Failed to generate full article.");
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: `A professional, high-quality blog header image representing: ${prompt}. Cinematic, vibrant, and detailed.`,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: '16:9',
            },
        });
        
        const base64ImageBytes = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;
    } catch (error) {
        console.error("Error generating image:", error);
        throw new Error("Failed to generate image.");
    }
};
