
import React, { useState, useEffect, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Toaster, toast } from 'react-hot-toast';
import { type Post } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Editor from './components/Editor';
import Preview from './components/Preview';
import AIPanel from './components/AIPanel';
import { DUMMY_POSTS } from './constants';
import { PlusCircle } from 'lucide-react';

const App: React.FC = () => {
    const [posts, setPosts] = useLocalStorage<Post[]>('blog-posts', DUMMY_POSTS);
    const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

    useEffect(() => {
        if (!selectedPostId && posts.length > 0) {
            setSelectedPostId(posts[0].id);
        }
         if (posts.length === 0) {
            setSelectedPostId(null);
        }
    }, [posts, selectedPostId]);

    const selectedPost = useMemo(() => {
        return posts.find(p => p.id === selectedPostId) || null;
    }, [posts, selectedPostId]);

    const handleCreatePost = () => {
        const newPost: Post = {
            id: uuidv4(),
            title: 'Untitled Post',
            content: 'Start writing your amazing blog post here...',
            imageUrl: null,
            createdAt: new Date().toISOString(),
        };
        const newPosts = [newPost, ...posts];
        setPosts(newPosts);
        setSelectedPostId(newPost.id);
        toast.success('New post created!');
    };

    const handleDeletePost = (id: string) => {
        const newPosts = posts.filter(p => p.id !== id);
        setPosts(newPosts);
        if (selectedPostId === id) {
            setSelectedPostId(newPosts.length > 0 ? newPosts[0].id : null);
        }
        toast.error('Post deleted!');
    };

    const handleUpdatePost = (updatedPost: Partial<Post>) => {
        if (!selectedPostId) return;
        setPosts(posts.map(p => p.id === selectedPostId ? { ...p, ...updatedPost } : p));
    };

    const handleSelectPost = (id: string) => {
        setSelectedPostId(id);
    };

    return (
        <div className="min-h-screen bg-primary text-text-primary font-sans flex flex-col">
            <Toaster position="top-right" toastOptions={{
                className: '!bg-tertiary !text-text-primary !border !border-gray-700',
                success: { iconTheme: { primary: '#388BFF', secondary: 'white' } },
                error: { iconTheme: { primary: '#EF4444', secondary: 'white' } },
            }} />
            <Header />
            <div className="flex-grow flex overflow-hidden">
                <Sidebar
                    posts={posts}
                    selectedPostId={selectedPostId}
                    onSelectPost={handleSelectPost}
                    onCreatePost={handleCreatePost}
                    onDeletePost={handleDeletePost}
                />
                <main className="flex-grow flex flex-col overflow-hidden">
                    {selectedPost ? (
                        <div className="grid grid-cols-1 lg:grid-cols-2 flex-grow overflow-hidden">
                            <div className="flex flex-col overflow-y-auto p-4 md:p-6 lg:p-8 bg-secondary">
                                <Editor post={selectedPost} onUpdatePost={handleUpdatePost} />
                                <AIPanel
                                    currentTitle={selectedPost.title}
                                    onUpdatePost={handleUpdatePost}
                                />
                            </div>
                            <div className="flex flex-col overflow-y-auto p-4 md:p-6 lg:p-8 bg-primary border-l border-tertiary">
                                <Preview post={selectedPost} />
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-text-secondary animate-fade-in">
                            <h2 className="text-2xl font-bold mb-4">No Post Selected</h2>
                            <p className="mb-6">Select a post from the sidebar or create a new one to get started.</p>
                             <button
                                onClick={handleCreatePost}
                                className="flex items-center gap-2 px-6 py-3 bg-accent-blue text-white font-semibold rounded-lg shadow-lg hover:bg-blue-500 transition-all duration-300 transform hover:scale-105"
                            >
                                <PlusCircle size={20} />
                                Create New Post
                            </button>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;
