import React from 'react';
import { NavLink } from 'react-router-dom';

const NavItem: React.FC<{ to: string; icon: string; label: string }> = ({ to, icon, label }) => {
  const activeClass = 'bg-sky-500/20 text-accent border-l-4 border-accent';
  const inactiveClass = 'text-light hover:bg-slate-700/50';

  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) => `flex items-center px-6 py-4 text-sm font-medium transition-colors duration-200 ${isActive ? activeClass : inactiveClass}`}
    >
      <i className={`fa-solid ${icon} w-6 h-6 mr-4`}></i>
      <span>{label}</span>
    </NavLink>
  );
};

const Sidebar: React.FC = () => {
  return (
    <aside className="hidden md:flex w-64 flex-col bg-secondary border-r border-slate-800">
      <div className="flex items-center justify-center h-20 border-b border-slate-800">
        <i className="fa-solid fa-rocket text-accent text-2xl mr-3"></i>
        <h1 className="text-xl font-bold text-superlight">Gemini CMS</h1>
      </div>
      <nav className="flex-1 py-6">
        <NavItem to="/" icon="fa-tachometer-alt" label="Dashboard" />
        <NavItem to="/posts" icon="fa-file-alt" label="Posts" />
        <NavItem to="/analytics" icon="fa-chart-line" label="Analytics" />
        <NavItem to="/autopilot" icon="fa-robot" label="Autopilot" />
        <NavItem to="/scheduler" icon="fa-calendar-check" label="Scheduler" />
        <NavItem to="/settings" icon="fa-cog" label="Settings" />
      </nav>
      <div className="p-6 border-t border-slate-800">
          <p className="text-xs text-slate-500">&copy; 2024 Gemini CMS Pro. All rights reserved.</p>
      </div>
    </aside>
  );
};

export default Sidebar;