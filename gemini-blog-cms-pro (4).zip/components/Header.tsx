
import React from 'react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-between h-20 px-6 bg-secondary border-b border-slate-800 flex-shrink-0">
      <div className="flex items-center">
        <h2 className="text-2xl font-semibold text-superlight">Welcome Back!</h2>
      </div>
      <div className="flex items-center space-x-4">
        <Link to="/posts/new" className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-accent rounded-md shadow-sm hover:bg-sky-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent transition-colors duration-200">
          <i className="fa-solid fa-plus mr-2"></i>
          New Post
        </Link>
        <button className="p-2 rounded-full text-light hover:bg-slate-700/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-secondary focus:ring-accent">
          <i className="fa-solid fa-bell"></i>
        </button>
        <div className="relative">
          <img
            className="h-10 w-10 rounded-full object-cover border-2 border-accent"
            src="https://picsum.photos/seed/user/100/100"
            alt="User avatar"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
