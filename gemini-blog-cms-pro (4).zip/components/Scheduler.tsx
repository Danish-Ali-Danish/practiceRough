import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import type { Post } from '../types';
import * as geminiService from '../services/geminiService';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';

interface SchedulerProps {
  onSave: (post: Post) => void;
}

type Frequency = 'daily' | 'weekly';
interface ActivityLog {
  postId: string;
  title: string;
  topic: string;
  createdAt: string;
}

const ToggleSwitch: React.FC<{ isEnabled: boolean; onChange: (enabled: boolean) => void }> = ({ isEnabled, onChange }) => (
  <label htmlFor="scheduler-toggle" className="flex items-center cursor-pointer">
    <div className="relative">
      <input type="checkbox" id="scheduler-toggle" className="sr-only" checked={isEnabled} onChange={(e) => onChange(e.target.checked)} />
      <div className="block bg-slate-700 w-14 h-8 rounded-full"></div>
      <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${isEnabled ? 'transform translate-x-full bg-accent' : ''}`}></div>
    </div>
    <div className={`ml-3 font-medium ${isEnabled ? 'text-accent' : 'text-light'}`}>
      {isEnabled ? 'Enabled' : 'Disabled'}
    </div>
  </label>
);

const Scheduler: React.FC<SchedulerProps> = ({ onSave }) => {
  const [isEnabled, setIsEnabled] = useState<boolean>(() => JSON.parse(localStorage.getItem('scheduler_isEnabled') || 'false'));
  const [topics, setTopics] = useState<string[]>(() => JSON.parse(localStorage.getItem('scheduler_topics') || '["Latest AI News"]'));
  const [newTopic, setNewTopic] = useState<string>('');
  const [frequency, setFrequency] = useState<Frequency>(() => (localStorage.getItem('scheduler_frequency') as Frequency) || 'daily');
  const [activityLog, setActivityLog] = useState<ActivityLog[]>(() => JSON.parse(localStorage.getItem('scheduler_activityLog') || '[]'));
  const [isGenerating, setIsGenerating] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    localStorage.setItem('scheduler_isEnabled', JSON.stringify(isEnabled));
    localStorage.setItem('scheduler_topics', JSON.stringify(topics));
    localStorage.setItem('scheduler_frequency', frequency);
    localStorage.setItem('scheduler_activityLog', JSON.stringify(activityLog));
  }, [isEnabled, topics, frequency, activityLog]);

  const runGeneration = useCallback(async (manualTrigger = false) => {
    if (isGenerating || topics.length === 0) return;

    if (!manualTrigger) {
      const lastRun = parseInt(localStorage.getItem('scheduler_lastRun') || '0', 10);
      const now = Date.now();
      const period = frequency === 'daily' ? 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000;
      if (now - lastRun < period) {
        return;
      }
    }

    setIsGenerating(true);
    try {
      const topic = topics[Math.floor(Math.random() * topics.length)];
      
      const { content, sources } = await geminiService.generateGroundedPost(topic);
      if (content.includes('Error Generating Post')) throw new Error(content);
      
      const title = await geminiService.generateTitle(`${topic}: ${content.substring(0, 400)}`);
      const featuredImage = await geminiService.generateImage(title);
      
      let finalContent = content;
      if (sources.length > 0) {
        const sourcesMarkdown = sources.map((s: any) => `- [${s.web.title}](${s.web.uri})`).join('\n');
        finalContent += `\n\n## Sources\n${sourcesMarkdown}`;
      }

      const newPost: Post = {
        id: new Date().toISOString(),
        title,
        content: finalContent,
        featuredImage,
        status: 'Published',
        createdAt: new Date().toISOString(),
        views: 0, comments: 0, likes: 0,
      };

      onSave(newPost);

      setActivityLog(prev => [{ postId: newPost.id, title: newPost.title, topic, createdAt: newPost.createdAt }, ...prev]);
      localStorage.setItem('scheduler_lastRun', Date.now().toString());

    } catch (error) {
      console.error('Scheduler generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  }, [isGenerating, topics, frequency, onSave]);

  useEffect(() => {
    if (isEnabled) {
      // Run once on enable, then set interval
      runGeneration();
      intervalRef.current = window.setInterval(() => {
        runGeneration();
      }, 60 * 60 * 1000); // Check every hour
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isEnabled, runGeneration]);

  const handleAddTopic = () => {
    if (newTopic.trim() && !topics.includes(newTopic.trim())) {
      setTopics([...topics, newTopic.trim()]);
      setNewTopic('');
    }
  };

  const handleRemoveTopic = (topicToRemove: string) => {
    setTopics(topics.filter(t => t !== topicToRemove));
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-superlight mb-2">Content Scheduler</h2>
        <p className="text-light max-w-3xl">Automate your content pipeline. The scheduler will periodically generate and publish new posts based on your chosen topics and frequency.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <h3 className="text-xl font-semibold text-superlight mb-4">Master Control</h3>
            <ToggleSwitch isEnabled={isEnabled} onChange={setIsEnabled} />
            <p className="text-sm text-slate-400 mt-3">When enabled, the scheduler will run automatically in the background.</p>
          </Card>

          <Card>
            <h3 className="text-xl font-semibold text-superlight mb-4">Topics</h3>
            <div className="flex space-x-2 mb-4">
              <input
                type="text"
                value={newTopic}
                onChange={(e) => setNewTopic(e.target.value)}
                placeholder="e.g., Quantum Computing"
                className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent text-superlight"
              />
              <Button onClick={handleAddTopic} disabled={!newTopic.trim()}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {topics.map(topic => (
                <span key={topic} className="flex items-center bg-slate-700 text-superlight text-sm font-medium px-3 py-1 rounded-full">
                  {topic}
                  <button onClick={() => handleRemoveTopic(topic)} className="ml-2 text-slate-400 hover:text-white">
                    <i className="fa-solid fa-times-circle"></i>
                  </button>
                </span>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="text-xl font-semibold text-superlight mb-4">Settings</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-light mb-2">Generation Frequency</label>
                <select value={frequency} onChange={(e) => setFrequency(e.target.value as Frequency)} className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent">
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-light mb-2">Manual Trigger</label>
                <Button onClick={() => runGeneration(true)} isLoading={isGenerating} disabled={isGenerating || topics.length === 0} icon="fa-bolt">
                  {isGenerating ? 'Generating...' : 'Generate & Publish Now'}
                </Button>
                {topics.length === 0 && <p className="text-xs text-yellow-400 mt-2">Please add at least one topic to enable generation.</p>}
              </div>
            </div>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="h-full">
            <h3 className="text-xl font-semibold text-superlight mb-4">Activity Log</h3>
            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
              {isGenerating && (
                 <div className="flex items-center p-3 text-sm text-accent bg-sky-500/10 rounded-md">
                    <Spinner size="sm" className="mr-3" />
                    <span>Generating new post...</span>
                 </div>
              )}
              {activityLog.length === 0 && !isGenerating ? (
                <p className="text-sm text-slate-400 text-center py-8">No activity yet. Enable the scheduler or use the manual trigger to generate a post.</p>
              ) : (
                activityLog.map(log => (
                  <div key={log.postId} className="p-3 bg-primary rounded-md border border-slate-800">
                    <Link to={`/posts/edit/${log.postId}`} className="font-semibold text-superlight hover:text-accent block truncate">{log.title}</Link>
                    <p className="text-sm text-slate-400 mt-1">Topic: <span className="font-medium">{log.topic}</span></p>
                    <p className="text-xs text-slate-500 mt-1">{new Date(log.createdAt).toLocaleString()}</p>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Scheduler;
