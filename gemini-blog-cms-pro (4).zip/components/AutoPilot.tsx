import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Post } from '../types';
import * as geminiService from '../services/geminiService';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';

interface AutoPilotProps {
  onSave: (post: Post) => void;
}

type GenerationStatus = 'idle' | 'searching' | 'writing' | 'imaging' | 'done' | 'error';

const TOPICS = [
  'Latest AI News',
  'Cybersecurity Updates',
  'Frontend Development Trends',
  'Quantum Computing Breakthroughs'
];

const StatusDisplay: React.FC<{ status: GenerationStatus, errorContent?: string }> = ({ status, errorContent }) => {
  if (status === 'idle') return null;

  const statusMap: Record<GenerationStatus, { icon: string; text: string; color: string }> = {
    idle: { icon: '', text: '', color: '' },
    searching: { icon: 'fa-magnifying-glass', text: 'Searching for the latest information...', color: 'text-accent' },
    writing: { icon: 'fa-pen-nib', text: 'Writing compelling blog content...', color: 'text-accent' },
    imaging: { icon: 'fa-palette', text: 'Generating a stunning featured image...', color: 'text-accent' },
    done: { icon: 'fa-check-circle', text: 'Generation complete! Review your new post below.', color: 'text-green-400' },
    error: { icon: 'fa-exclamation-triangle', text: 'An error occurred.', color: 'text-danger' },
  };

  const currentStatus = statusMap[status];

  return (
    <Card className="mt-8 text-center">
      <div className="flex flex-col items-center justify-center p-6">
        {status !== 'done' && status !== 'error' && <Spinner />}
        <i className={`fa-solid ${currentStatus.icon} text-3xl my-4 ${currentStatus.color}`}></i>
        <h3 className={`text-xl font-semibold ${currentStatus.color}`}>{currentStatus.text}</h3>
        {status === 'error' && <p className="mt-2 text-sm text-light max-w-prose">{errorContent}</p>}
      </div>
    </Card>
  );
};

const AutoPilot: React.FC<AutoPilotProps> = ({ onSave }) => {
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [generatedPost, setGeneratedPost] = useState<Partial<Post> | null>(null);
  const [errorContent, setErrorContent] = useState('');
  const [sources, setSources] = useState<any[]>([]);
  const navigate = useNavigate();

  const handleGenerate = async (topic: string) => {
    setStatus('searching');
    setGeneratedPost(null);
    setSources([]);
    setErrorContent('');

    try {
      const { content: groundedContent, sources: foundSources } = await geminiService.generateGroundedPost(topic);
      
      if (groundedContent.includes('Error Generating Post')) {
        throw new Error(groundedContent);
      }
      
      setStatus('writing');
      const title = await geminiService.generateTitle(`${topic}: ${groundedContent.substring(0, 400)}`);
      
      setStatus('imaging');
      const imageUrl = await geminiService.generateImage(title);

      let finalContent = groundedContent;
      if (foundSources.length > 0) {
        const sourcesMarkdown = foundSources
          .map((s: any) => `- [${s.web.title}](${s.web.uri})`)
          .join('\n');
        finalContent += `\n\n## Sources\n${sourcesMarkdown}`;
      }

      setGeneratedPost({
        title,
        content: finalContent,
        featuredImage: imageUrl,
        status: 'Draft',
      });
      setSources(foundSources);
      setStatus('done');

    } catch (err: any) {
      console.error("Autopilot generation failed:", err);
      setErrorContent(err.message || 'An unknown error occurred during generation.');
      setStatus('error');
    }
  };

  const handleSave = (publish: boolean) => {
    if (!generatedPost) return;
    const postToSave: Post = {
      id: new Date().toISOString(),
      title: generatedPost.title || 'Untitled',
      content: generatedPost.content || '',
      featuredImage: generatedPost.featuredImage,
      status: publish ? 'Published' : 'Draft',
      createdAt: new Date().toISOString(),
      views: 0,
      comments: 0,
      likes: 0,
    };
    onSave(postToSave);
    navigate('/posts');
  };

  const handleReset = () => {
    setStatus('idle');
    setGeneratedPost(null);
    setSources([]);
    setErrorContent('');
  };

  const isGenerating = ['searching', 'writing', 'imaging'].includes(status);

  return (
    <div>
      <h2 className="text-3xl font-bold text-superlight mb-4">AI Content Autopilot</h2>
      <p className="mb-8 text-light max-w-3xl">Let Gemini automatically find the latest information on a topic, write a high-quality blog post, generate a featured image, and cite its sources. Your content creation, accelerated.</p>
      
      {status === 'idle' && (
        <Card>
          <h3 className="text-xl font-semibold text-superlight mb-4">1. Choose a Topic</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {TOPICS.map(topic => (
              <Button key={topic} variant="secondary" onClick={() => handleGenerate(topic)} disabled={isGenerating}>
                {topic}
              </Button>
            ))}
          </div>
        </Card>
      )}

      {(isGenerating || status === 'done' || status === 'error') && (
        <StatusDisplay status={status} errorContent={errorContent} />
      )}

      {status === 'done' && generatedPost && (
        <div className="mt-8">
            <Card>
                {generatedPost.featuredImage && (
                    <img src={generatedPost.featuredImage} alt="Featured" className="w-full h-64 object-cover rounded-t-lg" />
                )}
                <div className="p-6">
                    <h3 className="text-2xl font-bold text-superlight mb-4">{generatedPost.title}</h3>
                    <div className="bg-primary p-4 rounded-md border border-slate-700 max-h-96 overflow-y-auto">
                        <pre className="whitespace-pre-wrap font-sans text-superlight">{generatedPost.content}</pre>
                    </div>
                </div>
            </Card>
            <div className="mt-6 flex items-center justify-end space-x-4">
                <Button variant="ghost" onClick={handleReset}>Discard & Start Over</Button>
                <Button variant="secondary" onClick={() => handleSave(false)}>Save as Draft</Button>
                <Button onClick={() => handleSave(true)}>Publish Post</Button>
            </div>
        </div>
      )}
       {status === 'error' && (
         <div className="mt-6 flex justify-center">
            <Button onClick={handleReset} variant="secondary">Try Again</Button>
         </div>
       )}
    </div>
  );
};

export default AutoPilot;
