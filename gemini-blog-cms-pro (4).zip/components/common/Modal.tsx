
import React from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70" aria-modal="true" role="dialog">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-md mx-4 border border-slate-700">
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <h3 className="text-lg font-semibold text-superlight">{title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-light hover:bg-slate-700 transition-colors"
            aria-label="Close modal"
          >
            <i className="fa-solid fa-times w-5 h-5"></i>
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;
