
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const textModel = "gemini-2.5-flash";
const imageModel = "imagen-3.0-generate-002";

export const generateTitle = async (topic: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: textModel,
      contents: `Generate a compelling, SEO-friendly blog post title about: "${topic}". The title should be short, catchy, and under 70 characters. Provide only the title text, with no extra formatting or quotation marks.`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 50,
      }
    });
    return response.text.trim().replace(/"/g, '');
  } catch (error) {
    console.error("Error generating title:", error);
    return "AI Generation Failed";
  }
};

export const generateOutline = async (title: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: textModel,
      contents: `Create a structured blog post outline for the title: "${title}". Use markdown for headings (e.g., #, ##, ###) and bullet points for sub-topics. The outline should be logical and cover key aspects of the topic.`,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating outline:", error);
    return "## AI Outline Generation Failed\n- Please try again.";
  }
};

export const generateFullPost = async (title: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: textModel,
      contents: `Write a complete, high-quality blog post for the title: "${title}". The post should be engaging, well-structured, and informative. Use markdown for formatting, including headings, bold text, and lists where appropriate. Ensure it has an introduction, a body with several sections, and a conclusion.`,
      config: {
        temperature: 0.6,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Error generating full post:", error);
    return `## Error Generating Post: ${title}\n\nAn error occurred while trying to generate the full blog post. Please check your connection and API key, and try again.`;
  }
};

export const generateImage = async (prompt: string): Promise<string> => {
  try {
    const fullPrompt = `A professional, high-resolution, cinematic blog post header image for an article about: "${prompt}". Photorealistic style.`;
    const response = await ai.models.generateImages({
      model: imageModel,
      prompt: fullPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '16:9',
      },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    }
    throw new Error("No image was generated.");
  } catch (error) {
    console.error("Error generating image:", error);
    return "";
  }
};
