
export interface Post {
  id: string;
  title: string;
  content: string;
  status: 'Published' | 'Draft';
  createdAt: string;
  views: number;
  comments: number;
  likes: number;
  featuredImage?: string;
}

export interface AnalyticsData {
  views: { date: string; value: number }[];
  likes: { date:string; value: number }[];
  comments: { date: string; value: number }[];
  topPosts: { title: string; views: number }[];
}
