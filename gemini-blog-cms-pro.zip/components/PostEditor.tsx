
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import type { Post } from '../types';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';
import * as geminiService from '../services/geminiService';

interface PostEditorProps {
  posts?: Post[];
  onSave: (post: Post) => void;
}

type AIGenerationState = 'idle' | 'loading' | 'error';
type AIFeature = 'title' | 'outline' | 'full' | 'image';

const PostEditor: React.FC<PostEditorProps> = ({ posts = [], onSave }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState<Partial<Post>>({
    title: '',
    content: '',
    status: 'Draft',
  });
  const [aiState, setAiState] = useState<Record<AIFeature, AIGenerationState>>({
    title: 'idle',
    outline: 'idle',
    full: 'idle',
    image: 'idle'
  });

  useEffect(() => {
    if (id) {
      const existingPost = posts.find(p => p.id === id);
      if (existingPost) {
        setPost(existingPost);
      }
    }
  }, [id, posts]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPost(prev => ({ ...prev, [name]: value }));
  };

  const handleAISubmit = async (feature: AIFeature) => {
    setAiState(prev => ({ ...prev, [feature]: 'loading' }));
    try {
      switch (feature) {
        case 'title':
            const topic = post.title || 'a random web development topic';
            const newTitle = await geminiService.generateTitle(topic);
            setPost(prev => ({...prev, title: newTitle}));
            break;
        case 'outline':
            if (!post.title) return alert("Please enter a title first.");
            const outline = await geminiService.generateOutline(post.title);
            setPost(prev => ({...prev, content: outline}));
            break;
        case 'full':
            if (!post.title) return alert("Please enter a title first.");
            const fullPost = await geminiService.generateFullPost(post.title);
            setPost(prev => ({...prev, content: fullPost}));
            break;
        case 'image':
            if (!post.title) return alert("Please enter a title first to generate a relevant image.");
            const imageUrl = await geminiService.generateImage(post.title);
            setPost(prev => ({...prev, featuredImage: imageUrl}));
            break;
      }
      setAiState(prev => ({ ...prev, [feature]: 'idle' }));
    } catch (error) {
      console.error(`AI generation for ${feature} failed:`, error);
      setAiState(prev => ({ ...prev, [feature]: 'error' }));
    }
  };

  const handleSave = () => {
    const finalPost: Post = {
      id: post.id || new Date().toISOString(),
      title: post.title || 'Untitled Post',
      content: post.content || '',
      status: post.status || 'Draft',
      createdAt: post.createdAt || new Date().toISOString(),
      views: post.views || 0,
      comments: post.comments || 0,
      likes: post.likes || 0,
      featuredImage: post.featuredImage
    };
    onSave(finalPost);
  };
  
  const AIToolButton: React.FC<{feature: AIFeature, children: React.ReactNode}> = ({feature, children}) => (
     <Button 
        variant="secondary" 
        onClick={() => handleAISubmit(feature)} 
        isLoading={aiState[feature] === 'loading'}
        className="bg-slate-700/80 hover:bg-slate-600 text-xs"
      >
        <i className="fa-solid fa-wand-magic-sparkles text-accent mr-2"></i>
        {children}
      </Button>
  );


  return (
    <div>
        <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-superlight">{id ? 'Edit Post' : 'Create New Post'}</h2>
            <div className="flex items-center space-x-4">
                <Button variant="secondary" onClick={() => navigate('/posts')}>Cancel</Button>
                <Button onClick={handleSave} icon="fa-save">Save Post</Button>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
                <Card>
                    <label htmlFor="title" className="block text-sm font-medium text-light mb-2">Title</label>
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            name="title"
                            id="title"
                            value={post.title}
                            onChange={handleInputChange}
                            placeholder="Enter a great title..."
                            className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent text-superlight"
                        />
                         <AIToolButton feature="title">Generate</AIToolButton>
                    </div>
                </Card>
                <Card>
                     <div className="flex items-center justify-between mb-2">
                        <label htmlFor="content" className="block text-sm font-medium text-light">Content</label>
                        <div className="flex items-center space-x-2">
                             <AIToolButton feature="outline">Generate Outline</AIToolButton>
                             <AIToolButton feature="full">Write Full Post</AIToolButton>
                        </div>
                     </div>
                    <textarea
                        name="content"
                        id="content"
                        value={post.content}
                        onChange={handleInputChange}
                        rows={20}
                        placeholder="Start writing your amazing blog post here..."
                        className="w-full bg-primary border border-slate-700 rounded-md p-3 focus:ring-accent focus:border-accent text-superlight font-mono text-sm"
                    />
                </Card>
            </div>
            <div className="space-y-6">
                <Card>
                    <h3 className="text-lg font-semibold text-superlight mb-4">Publish Settings</h3>
                    <label htmlFor="status" className="block text-sm font-medium text-light mb-2">Status</label>
                    <select
                        name="status"
                        id="status"
                        value={post.status}
                        onChange={handleInputChange}
                        className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent"
                    >
                        <option value="Draft">Draft</option>
                        <option value="Published">Published</option>
                    </select>
                </Card>
                 <Card>
                    <h3 className="text-lg font-semibold text-superlight mb-4">Featured Image</h3>
                    {aiState.image === 'loading' ? (
                      <div className="flex flex-col items-center justify-center h-48 bg-primary rounded-md border-2 border-dashed border-slate-700">
                        <Spinner />
                        <p className="mt-2 text-sm">Generating image...</p>
                      </div>
                    ) : post.featuredImage ? (
                       <img src={post.featuredImage} alt="Featured" className="w-full h-48 object-cover rounded-md" />
                    ) : (
                      <div className="flex items-center justify-center h-48 bg-primary rounded-md border-2 border-dashed border-slate-700">
                        <p className="text-sm">No image set</p>
                      </div>
                    )}
                    <div className="mt-4">
                      <AIToolButton feature="image">Generate with AI</AIToolButton>
                    </div>
                </Card>
            </div>
        </div>
    </div>
  );
};

export default PostEditor;
