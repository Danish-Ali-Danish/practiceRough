
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { MOCK_ANALYTICS_DATA } from '../constants';
import type { AnalyticsData } from '../types';
import Card from './common/Card';

const Analytics: React.FC = () => {
  const data: AnalyticsData = MOCK_ANALYTICS_DATA;

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-superlight">Analytics</h2>

      <Card>
        <h3 className="text-xl font-semibold text-superlight mb-6">Audience Overview</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={data.views} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="date" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" />
            <Tooltip
              contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155' }}
              labelStyle={{ color: '#e2e8f0' }}
            />
            <Legend wrapperStyle={{ color: '#e2e8f0' }} />
            <Line type="monotone" dataKey="value" name="Views" stroke="#38bdf8" strokeWidth={2} activeDot={{ r: 8 }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <h3 className="text-xl font-semibold text-superlight mb-6">Top Posts by Views</h3>
           <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.topPosts} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="title" type="category" stroke="#94a3b8" width={120} tick={{ fontSize: 12 }} />
                <Tooltip
                  cursor={{ fill: '#334155' }}
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Bar dataKey="views" fill="#38bdf8" />
            </BarChart>
           </ResponsiveContainer>
        </Card>
        <Card>
          <h3 className="text-xl font-semibold text-superlight mb-6">Engagement (Likes vs Comments)</h3>
           <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.likes} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Legend />
                <Line type="monotone" dataKey="value" name="Likes" stroke="#ec4899" />
                <Line type="monotone" dataKey="value" data={data.comments} name="Comments" stroke="#4ade80" />
            </LineChart>
           </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
};

export default Analytics;
