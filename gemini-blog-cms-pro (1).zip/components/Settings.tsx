
import React from 'react';
import Card from './common/Card';
import Button from './common/Button';

const Settings: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-superlight mb-8">Settings</h2>
      
      <div className="space-y-8">
        <Card>
          <h3 className="text-xl font-semibold text-superlight border-b border-slate-700 pb-4 mb-4">Profile</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-light mb-1">Username</label>
              <input type="text" defaultValue="AdminUser" className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-light mb-1">Email</label>
              <input type="email" defaultValue="admin@geminicms.pro" className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent"/>
            </div>
            <Button>Update Profile</Button>
          </div>
        </Card>

        <Card>
          <h3 className="text-xl font-semibold text-superlight border-b border-slate-700 pb-4 mb-4">Blog Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-light mb-1">Blog Title</label>
              <input type="text" defaultValue="My Awesome Gemini Blog" className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent"/>
            </div>
            <div>
              <label className="block text-sm font-medium text-light mb-1">Tagline</label>
              <input type="text" defaultValue="Exploring the future, one post at a time." className="w-full bg-primary border border-slate-700 rounded-md p-2 focus:ring-accent focus:border-accent"/>
            </div>
            <Button>Save Settings</Button>
          </div>
        </Card>
        
        <Card>
          <h3 className="text-xl font-semibold text-superlight border-b border-slate-700 pb-4 mb-4">Danger Zone</h3>
            <div className="flex items-center justify-between p-4 bg-primary rounded-md border border-danger/50">
              <div>
                <h4 className="font-bold text-red-400">Delete All Content</h4>
                <p className="text-sm text-light">This action is irreversible and will permanently delete all posts.</p>
              </div>
              <Button variant="danger">Delete All</Button>
            </div>
        </Card>
      </div>
    </div>
  );
};

export default Settings;
