import React, { useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import type { Post } from './types';
import { INITIAL_POSTS } from './constants';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import PostList from './components/PostList';
import PostEditor from './components/PostEditor';
import Analytics from './components/Analytics';
import Settings from './components/Settings';
import AutoPilot from './components/AutoPilot';

const App: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const navigate = useNavigate();

  const handleSavePost = (postToSave: Post) => {
    const existingPostIndex = posts.findIndex(p => p.id === postToSave.id);
    if (existingPostIndex > -1) {
      const updatedPosts = [...posts];
      updatedPosts[existingPostIndex] = postToSave;
      setPosts(updatedPosts);
    } else {
      setPosts([postToSave, ...posts]);
    }
    navigate('/posts');
  };

  const handleDeletePost = (postId: string) => {
    setPosts(posts.filter(p => p.id !== postId));
  };
  
  return (
    <div className="flex h-screen bg-primary text-light font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-primary p-6 md:p-8">
          <Routes>
            <Route path="/" element={<Dashboard posts={posts} />} />
            <Route path="/posts" element={<PostList posts={posts} onDelete={handleDeletePost} />} />
            <Route path="/posts/new" element={<PostEditor onSave={handleSavePost} />} />
            <Route path="/posts/edit/:id" element={<PostEditor posts={posts} onSave={handleSavePost} />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/autopilot" element={<AutoPilot onSave={handleSavePost} />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default App;
