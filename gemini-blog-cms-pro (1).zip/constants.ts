
import type { Post, AnalyticsData } from './types';

export const INITIAL_POSTS: Post[] = [
  {
    id: '1',
    title: 'The Future of AI in Web Development',
    content: 'AI is revolutionizing how we build websites. From intelligent code completion to automated testing, the possibilities are endless...',
    status: 'Published',
    createdAt: '2023-10-26',
    views: 1250,
    comments: 45,
    likes: 320,
    featuredImage: 'https://picsum.photos/seed/ai/800/400'
  },
  {
    id: '2',
    title: 'Mastering React Hooks in 2024',
    content: 'useState, useEffect, useContext... React Hooks are powerful tools. This guide will walk you through advanced patterns and best practices.',
    status: 'Published',
    createdAt: '2023-10-22',
    views: 2800,
    comments: 112,
    likes: 850,
    featuredImage: 'https://picsum.photos/seed/react/800/400'
  },
  {
    id: '3',
    title: 'A Deep Dive into Tailwind CSS',
    content: 'Forget writing custom CSS. Tailwind CSS provides utility classes that let you build any design directly in your markup.',
    status: 'Draft',
    createdAt: '2023-11-01',
    views: 0,
    comments: 0,
    likes: 0,
    featuredImage: 'https://picsum.photos/seed/tailwind/800/400'
  }
];

export const MOCK_ANALYTICS_DATA: AnalyticsData = {
  views: [
    { date: 'Jan', value: 2400 },
    { date: 'Feb', value: 1398 },
    { date: 'Mar', value: 9800 },
    { date: 'Apr', value: 3908 },
    { date: 'May', value: 4800 },
    { date: 'Jun', value: 3800 },
    { date: 'Jul', value: 4300 },
  ],
  likes: [
    { date: 'Jan', value: 1200 },
    { date: 'Feb', value: 800 },
    { date: 'Mar', value: 4500 },
    { date: 'Apr', value: 2000 },
    { date: 'May', value: 2400 },
    { date: 'Jun', value: 1900 },
    { date: 'Jul', value: 2100 },
  ],
  comments: [
    { date: 'Jan', value: 240 },
    { date: 'Feb', value: 140 },
    { date: 'Mar', value: 980 },
    { date: 'Apr', value: 390 },
    { date: 'May', value: 480 },
    { date: 'Jun', value: 380 },
    { date: 'Jul', value: 430 },
  ],
  topPosts: INITIAL_POSTS
    .filter(p => p.status === 'Published')
    .sort((a, b) => b.views - a.views)
    .slice(0, 5),
};
