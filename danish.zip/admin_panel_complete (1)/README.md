# Laravel Admin Panel — Complete Admin Side Skeleton

This package contains a complete **admin-side** Laravel skeleton (design-preserving) that you can merge into a Laravel project.
It includes:
- Admin layout (sidebar + topbar)
- Dashboard and pages: dashboard, posts (list/create/edit), categories, users (list/create/edit),
  comments, settings, profile, index redirect.
- Controllers for admin functionality
- Models and migrations: posts, categories, comments (users use Laravel default)
- Middleware: isAdmin
- Routes: admin prefixed routes
- Instructions to install into a full Laravel project and run

**Important:** This is a skeleton. It does not include vendor/ (composer) files. Copy the files into a Laravel project or create a fresh Laravel project and merge these files.
