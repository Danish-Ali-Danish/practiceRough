@extends('admin.layouts.app')
@section('title','Edit User')
@section('content')
<form action="{{ route('admin.users.update',$user) }}" method="POST" class="bg-white p-6 rounded shadow">@csrf @method('PUT')
    <div><label>Name</label><input name="name" value="{{ $user->name }}" class="w-full border p-2" required></div>
    <div class="mt-2"><label>Email</label><input name="email" value="{{ $user->email }}" class="w-full border p-2" required></div>
    <div class="mt-2"><label>Is Admin</label><input type="checkbox" name="is_admin" value="1" @if($user->is_admin) checked @endif></div>
    <div class="mt-4"><button class="px-4 py-2 bg-yellow-600 text-white rounded">Update</button></div>
</form>
@endsection
