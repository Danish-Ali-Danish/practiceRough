@extends('admin.layouts.app')
@section('title','Users')
@section('content')
<div class="flex justify-between items-center mb-4"><h2 class="text-xl font-bold">Users</h2>
    <a href="{{ route('admin.users.create') }}" class="px-4 py-2 bg-blue-600 text-white rounded">New User</a>
</div>
<table class="min-w-full bg-white"><thead><tr><th class="px-4 py-2">Name</th><th class="px-4 py-2">Email</th><th class="px-4 py-2">Admin</th><th class="px-4 py-2">Actions</th></tr></thead>
<tbody>@foreach($users as $u)<tr class="border-t"><td class="px-4 py-2">{{ $u->name }}</td><td class="px-4 py-2">{{ $u->email }}</td><td class="px-4 py-2">{{ $u->is_admin ? 'Yes' : 'No' }}</td><td class="px-4 py-2"><a href="{{ route('admin.users.edit',$u) }}">Edit</a>
<form action="{{ route('admin.users.destroy',$u) }}" method="POST" style="display:inline">@csrf @method('DELETE')
<button onclick="return confirm('Delete?')">Delete</button></form></td></tr>@endforeach</tbody></table>
<div class="mt-4">{{ $users->links() }}</div>
@endsection
