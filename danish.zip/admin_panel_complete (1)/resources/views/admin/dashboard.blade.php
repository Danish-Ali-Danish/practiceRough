@extends('admin.layouts.app')

@section('title','Dashboard')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div class="bg-white p-6 rounded shadow">
        <h3 class="font-bold">Total Posts</h3>
        <p class="text-3xl">{{ $totalPosts }}</p>
    </div>
    <div class="bg-white p-6 rounded shadow">
        <h3 class="font-bold">Users</h3>
        <p class="text-3xl">{{ $totalUsers }}</p>
    </div>
    <div class="bg-white p-6 rounded shadow">
        <h3 class="font-bold">Pending Comments</h3>
        <p class="text-3xl">{{ $pendingComments }}</p>
    </div>
</div>

<div class="mt-6 bg-white p-4 rounded shadow">
    <h4 class="font-bold mb-2">Latest Posts</h4>
    <ul>
        @foreach($latestPosts as $p)
            <li class="border-b py-2">{{ $p->title }} <span class="text-sm text-gray-500">by {{ $p->user->name ?? 'Unknown' }}</span></li>
        @endforeach
    </ul>
</div>
@endsection
