@extends('admin.layouts.app')
@section('title','Profile')
@section('content')
<form action="{{ route('admin.profile.update') }}" method="POST" class="bg-white p-6 rounded shadow">@csrf
    <div><label>Name</label><input name="name" value="{{ $user->name }}" class="w-full border p-2" required></div>
    <div class="mt-2"><label>Email</label><input name="email" value="{{ $user->email }}" class="w-full border p-2" required></div>
    <div class="mt-4"><button class="px-4 py-2 bg-green-600 text-white rounded">Update Profile</button></div>
</form>
@endsection
