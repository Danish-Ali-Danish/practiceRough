@extends('admin.layouts.app')
@section('title','Create Post')
@section('content')
<form action="{{ route('admin.posts.store') }}" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
    @csrf
    <div><label>Title</label><input name="title" class="w-full border p-2" required></div>
    <div class="mt-2"><label>Category</label><select name="category_id" class="w-full border p-2">
        <option value="">-- Select --</option>
        @foreach($categories as $c)
            <option value="{{ $c->id }}">{{ $c->name }}</option>
        @endforeach
    </select></div>
    <div class="mt-2"><label>Content</label><textarea name="content" class="w-full border p-2" rows="8" required></textarea></div>
    <div class="mt-2"><label>Image</label><input type="file" name="image"></div>
    <div class="mt-4"><button class="px-4 py-2 bg-green-600 text-white rounded">Save</button></div>
</form>
@endsection
