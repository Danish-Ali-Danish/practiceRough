@extends('admin.layouts.app')
@section('title','Edit Post')
@section('content')
<form action="{{ route('admin.posts.update',$post) }}" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
    @csrf @method('PUT')
    <div><label>Title</label><input name="title" value="{{ $post->title }}" class="w-full border p-2" required></div>
    <div class="mt-2"><label>Category</label><select name="category_id" class="w-full border p-2">
        <option value="">-- Select --</option>
        @foreach($categories as $c)
            <option value="{{ $c->id }}" @if($post->category_id==$c->id) selected @endif>{{ $c->name }}</option>
        @endforeach
    </select></div>
    <div class="mt-2"><label>Content</label><textarea name="content" class="w-full border p-2" rows="8" required>{{ $post->content }}</textarea></div>
    <div class="mt-2"><label>Image</label><input type="file" name="image">@if($post->image)<p class="text-sm">Existing: {{ $post->image }}</p>@endif</div>
    <div class="mt-4"><button class="px-4 py-2 bg-yellow-600 text-white rounded">Update</button></div>
</form>
@endsection
