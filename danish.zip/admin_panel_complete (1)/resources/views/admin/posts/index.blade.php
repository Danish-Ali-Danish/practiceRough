@extends('admin.layouts.app')
@section('title','Posts')
@section('content')
<div class="flex justify-between items-center mb-4">
    <h2 class="text-xl font-bold">Posts</h2>
    <a href="{{ route('admin.posts.create') }}" class="px-4 py-2 bg-blue-600 text-white rounded">New Post</a>
</div>
<table class="min-w-full bg-white">
    <thead><tr><th class="px-4 py-2">Title</th><th class="px-4 py-2">Status</th><th class="px-4 py-2">Actions</th></tr></thead>
    <tbody>
        @foreach($posts as $post)
        <tr class="border-t">
            <td class="px-4 py-2">{{ $post->title }}</td>
            <td class="px-4 py-2">{{ $post->status }}</td>
            <td class="px-4 py-2">
                <a href="{{ route('admin.posts.edit',$post) }}" class="mr-2">Edit</a>
                <form action="{{ route('admin.posts.destroy',$post) }}" method="POST" style="display:inline">@csrf @method('DELETE')
                    <button onclick="return confirm('Delete?')">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<div class="mt-4">{{ $posts->links() }}</div>
@endsection
