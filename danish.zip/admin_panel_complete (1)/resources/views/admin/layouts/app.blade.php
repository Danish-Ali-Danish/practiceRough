<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin - @yield('title')</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow h-screen sticky top-0">
            <div class="p-4 font-bold text-xl">Admin Panel</div>
            <nav class="mt-4">
                <a href="{{ route('admin.dashboard') }}" class="block px-4 py-2 hover:bg-gray-100">Dashboard</a>
                <a href="{{ route('admin.posts.index') }}" class="block px-4 py-2 hover:bg-gray-100">Posts</a>
                <a href="{{ route('admin.categories.index') }}" class="block px-4 py-2 hover:bg-gray-100">Categories</a>
                <a href="{{ route('admin.users.index') }}" class="block px-4 py-2 hover:bg-gray-100">Users</a>
                <a href="{{ route('admin.comments.index') }}" class="block px-4 py-2 hover:bg-gray-100">Comments</a>
                <a href="{{ route('admin.settings') }}" class="block px-4 py-2 hover:bg-gray-100">Settings</a>
            </nav>
        </aside>

        <!-- Content -->
        <div class="flex-1">
            <header class="bg-white shadow p-4 flex justify-between items-center">
                <div class="font-bold">@yield('title')</div>
                <div>
                    <span class="mr-4">{{ auth()->user()->name ?? 'Admin' }}</span>
                    <a href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="text-sm text-red-600">Logout</a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none">@csrf</form>
                </div>
            </header>

            <main class="p-6">
                @if(session('success'))
                    <div class="mb-4 p-3 bg-green-100 text-green-800 rounded">{{ session('success') }}</div>
                @endif
                @yield('content')
            </main>
        </div>
    </div>
</body>
</html>
