@extends('admin.layouts.app')
@section('title','Create Category')
@section('content')
<form action="{{ route('admin.categories.store') }}" method="POST" class="bg-white p-6 rounded shadow">@csrf
    <div><label>Name</label><input name="name" class="w-full border p-2" required></div>
    <div class="mt-4"><button class="px-4 py-2 bg-green-600 text-white rounded">Create</button></div>
</form>
@endsection
