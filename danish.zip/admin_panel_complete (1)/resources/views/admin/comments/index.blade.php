@extends('admin.layouts.app')
@section('title','Comments')
@section('content')
<h2 class="text-xl font-bold mb-4">Comments</h2>
<table class="min-w-full bg-white"><thead><tr><th class="px-4 py-2">Post</th><th class="px-4 py-2">User</th><th class="px-4 py-2">Content</th><th class="px-4 py-2">Status</th><th class="px-4 py-2">Actions</th></tr></thead>
<tbody>@foreach($comments as $c)
<tr class="border-t"><td class="px-4 py-2">{{ $c->post->title ?? '—' }}</td><td class="px-4 py-2">{{ $c->user->name ?? 'Guest' }}</td><td class="px-4 py-2">{{ Str::limit($c->content,80) }}</td>
<td class="px-4 py-2">{{ $c->status }}</td>
<td class="px-4 py-2">
<form action="{{ route('admin.comments.approve',$c) }}" method="POST" style="display:inline">@csrf<button class="mr-2">Approve</button></form>
<form action="{{ route('admin.comments.reject',$c) }}" method="POST" style="display:inline">@csrf<button>Reject</button></form>
</td></tr>
@endforeach</tbody></table>
<div class="mt-4">{{ $comments->links() }}</div>
@endsection
