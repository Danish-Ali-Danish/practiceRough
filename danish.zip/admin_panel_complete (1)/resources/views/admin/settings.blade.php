@extends('admin.layouts.app')
@section('title','Settings')
@section('content')
<div class="bg-white p-6 rounded shadow">Settings page (placeholder). You can add site settings here.</div>
@endsection
