<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\PostController as AdminPostController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CommentController;
use App\Http\Controllers\Admin\ProfileController;
use Illuminate\Support\Facades\Auth;

Auth::routes();

Route::get('/', function(){ return redirect()->route('admin.dashboard'); });

Route::middleware(['auth','isAdmin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('dashboard',[DashboardController::class,'index'])->name('dashboard');

    Route::resource('posts', AdminPostController::class);
    Route::resource('categories', CategoryController::class)->except(['show']);
    Route::resource('users', UserController::class)->except(['show']);
    Route::get('comments',[CommentController::class,'index'])->name('comments.index');
    Route::post('comments/{comment}/approve',[CommentController::class,'approve'])->name('comments.approve');
    Route::post('comments/{comment}/reject',[CommentController::class,'reject'])->name('comments.reject');

    Route::get('settings',[DashboardController::class,'settings'])->name('settings');
    Route::get('profile',[ProfileController::class,'edit'])->name('profile.edit');
    Route::post('profile',[ProfileController::class,'update'])->name('profile.update');
});
