<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\User;
use App\Models\Comment;
use App\Models\Category;

class DashboardController extends Controller
{
    public function index()
    {
        $data = [
            'totalPosts' => Post::count(),
            'totalUsers' => User::count(),
            'pendingComments' => Comment::where('status','pending')->count(),
            'totalCategories' => Category::count(),
            'latestPosts' => Post::latest()->take(5)->get(),
        ];
        return view('admin.dashboard', $data);
    }

    public function settings(){
        return view('admin.settings');
    }
}
