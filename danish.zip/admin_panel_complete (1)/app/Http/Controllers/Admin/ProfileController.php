<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function edit(){
        $user = auth()->user();
        return view('admin.profile', compact('user'));
    }

    public function update(Request $request){
        $user = auth()->user();
        $request->validate(['name'=>'required','email'=>'required|email']);
        $user->update($request->only(['name','email']));
        return back()->with('success','Profile updated');
    }
}
