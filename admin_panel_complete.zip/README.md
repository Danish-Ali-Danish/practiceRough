Laravel Admin Panel Skeleton - Dynamic Admin Side
